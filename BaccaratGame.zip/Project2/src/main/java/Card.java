/**
 * Represents a playing card with a suite, a value, and optionally a face card designation.
 */
class Card {
    // The suite of the card (e.g., "Hearts", "Diamonds", "Clubs", "Spades")
    String suite;

    // The numeric value of the card (e.g., 2, 3, ...10, with face cards also having values, usually 0 or 1 for Ace)
    int value;

    // Designation for face cards (e.g., "Jack", "Queen", "King", "Ace"). This field will be null for numeric cards.
    String FaceCard;

    /**
     * Constructor for cards with numeric values.
     * 
     * @param theSuite The suite of the card.
     * @param theValue The numeric value of the card.
     */
    Card(String theSuite, int theValue) {
        this.suite = theSuite;
        this.value = theValue;
    }

    /**
     * Constructor for face cards.
     * 
     * @param theSuite  The suite of the card.
     * @param theFaceCard Designation for the face card.
     * @param value Numeric value associated with the face card.
     */
    Card(String theSuite, String theFaceCard, int value) {
        this.suite = theSuite;
        this.FaceCard = theFaceCard;
        this.value = value;
    }
}
