import java.util.ArrayList;
import java.util.Collections;

class BaccaratDealer {

    // Represents the deck of cards
    ArrayList<Card> deck;

    // Constructor: initializes an empty deck and then generates a complete deck
    public BaccaratDealer() {
        this.deck = new ArrayList<>();
        generateDeck();
    }

    // Generates a full deck of 52 cards for Baccarat (value 10, Jack, King, Queen have a point value of 0)
    public void generateDeck() {
        // The four suites in a deck of cards
        String[] suites = {"Hearts", "Diamonds", "Clubs", "Spades"};
        for (String suite : suites) {
            // Add cards 2 to 9 for each suite
            for (int i = 2; i <= 9; i++) {
                deck.add(new Card(suite, i));
            }
            // Add the face cards and 10, with their respective values for Baccarat
            deck.add(new Card(suite, "10", 0));
            deck.add(new Card(suite, "Jack", 0));
            deck.add(new Card(suite, "King", 0));
            deck.add(new Card(suite, "Queen", 0));
            deck.add(new Card(suite, "Ace", 1));
        }
    }

    // Deals a hand of two cards
    public ArrayList<Card> dealHand() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(drawOne());
        hand.add(drawOne());
        return hand;
    }

    // Draws one card from the deck. If the deck is empty, it generates and shuffles a new deck.
    public Card drawOne() {
        if(deck.isEmpty()) {
            generateDeck();
            shuffleDeck();
        }
        // Remove and return the top card of the deck
        return deck.remove(0);
    }

    // Shuffles the deck of cards
    public void shuffleDeck() {
        Collections.shuffle(deck);
    }

    // Returns the current size of the deck
    public int deckSize() {
        return deck.size();
    }
}
