import java.util.ArrayList;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

public class BaccaratGame extends Application {
    
    // Attributes related to the game's state and display
    ArrayList<Card> playerHand;
    ArrayList<Card> bankerHand;
    BaccaratDealer theDealer;
    BaccaratGameLogic gameLogic;
    double currentBet;
    double totalWinnings;
    Label infoLabel;
    Label totalWinningsLabel;
    private Label playerCardsLabel;
    private Label bankerCardsLabel;
    Stage primaryStage;
    Button playAgainButton;
    VBox bettingBox;
    String betType;


    // Method to delay execution of a specific action
    private void delayAction(Runnable action, double seconds) {
        PauseTransition pause = new PauseTransition(Duration.seconds(seconds));
        pause.setOnFinished(e -> action.run());
        pause.play();
    }
    


    // Method to create the main menu bar at the top of the application
    private MenuBar createMenuBar() {
        Menu gameMenu = new Menu("Game");

        // Start game menu item
        MenuItem startGameItem = new MenuItem("Start Game");
        startGameItem.setOnAction(e -> startGame());

        // Exit application menu item
        MenuItem exitItem = new MenuItem("Exit");
        exitItem.setOnAction(e -> Platform.exit());

        gameMenu.getItems().addAll(startGameItem, exitItem);

        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(gameMenu);
        return menuBar;
    }
    
    // Method to manage the round's flow
    private void playRound(String betType) {
        theDealer.shuffleDeck();

        playerHand = theDealer.dealHand();
        bankerHand = theDealer.dealHand();
        updateCardDisplay();

        delayAction(() -> {
            int playerScore = gameLogic.handTotal(playerHand);
            int bankerScore = gameLogic.handTotal(bankerHand);

            // Check if either player or banker has a natural win (score of 8 or 9)
            if ((playerScore >= 8) || (bankerScore >= 8)) {
                concludeRound(betType);
                return;
            }

            // Draw logic for player and banker
            if (gameLogic.evaluatePlayerDraw(playerHand)) {
                playerHand.add(theDealer.drawOne());
                updateCardDisplay();

                delayAction(() -> {
                    if (gameLogic.evaluateBankerDraw(bankerHand, playerHand.get(playerHand.size() - 1))) {
                        bankerHand.add(theDealer.drawOne());
                        updateCardDisplay();
                    }
                    concludeRound(betType);
                }, 2);
            } else {
                if (gameLogic.evaluateBankerDraw(bankerHand, null)) {
                    bankerHand.add(theDealer.drawOne());
                    updateCardDisplay();
                }
                concludeRound(betType);
            }
        }, 2);
    }
    
    // Method to display total winnings in the game
    private void updateTotalWinningsDisplay() {
        totalWinningsLabel.setText("Total Winnings: $" + totalWinnings);
    }
    
    
    // Evaluate player's bet and return the amount won or lost
    public double evaluateWinnings() {
        String winner = gameLogic.whoWon(playerHand, bankerHand);

        // If the player's bet matches the game's result
        if (winner.equals(betType)) {
            if (winner.equals("Draw")) {
                return currentBet * 8; // 8:1 payout for Draw
            } else if (winner.equals("Player")) {
                return currentBet; // 1:1 payout for Player win
            } else { // Banker win
                return currentBet - (currentBet * 0.05); // 1:1 payout but with 5% commission for Banker win
            }
        } else {
            // If the player's bet does NOT match the game's result
            return -currentBet;
        }
    }


    
    //Finishes round 
    private void concludeRound(String betType) {
    	String winner = gameLogic.whoWon(playerHand, bankerHand);
        
        double resultAmount = evaluateWinnings();
        totalWinnings += resultAmount;

        String resultMessage;
        if (resultAmount > 0) {
            resultMessage = winner + " won! You won $" + resultAmount;
        } else {
            resultMessage = winner + " won. You lost $" + Math.abs(resultAmount);
        }

        updateTotalWinningsDisplay();
        infoLabel.setText(resultMessage);
        
        playAgainButton.setVisible(true);
        bettingBox.setVisible(false);
    }
    
    //Places bets 
    private void placeBet(String betType, double amount) {
        this.betType = betType;  // Save the bet type
        bettingBox.setVisible(true);
        playAgainButton.setVisible(false);
        currentBet = amount;
        playRound(betType);  
    }

    //Resets round 
    private void resetRound() {
        bettingBox.setVisible(true);
        playAgainButton.setVisible(false);
        infoLabel.setText("Place your bet!");
        playerCardsLabel.setText("Player cards: ");
        bankerCardsLabel.setText("Banker cards: ");
    }
    
    
    //Updates what each player's card has 
    private void updateCardDisplay() {
        StringBuilder playerCardsText = new StringBuilder("Player cards: ");
        for (Card card : playerHand) {
        	if(card.value==0) {
        		playerCardsText.append(card.FaceCard).append(" of ").append(card.suite).append(", ");
        	}
        	else {
        		playerCardsText.append(card.value).append(" of ").append(card.suite).append(", ");
        	}
            
        }
        playerCardsLabel.setText(playerCardsText.toString());

        StringBuilder bankerCardsText = new StringBuilder("Banker cards: ");
        for (Card card : bankerHand) {
        	if(card.value==0) {
        		bankerCardsText.append(card.FaceCard).append(" of ").append(card.suite).append(", ");
        	}
        	else {
        		bankerCardsText.append(card.value).append(" of ").append(card.suite).append(", ");

        	}
        }
        bankerCardsLabel.setText(bankerCardsText.toString());
    }
    
    
    // Method to start a new game round
    private void startGame() {
        
        // Initialize total winnings for the player
        totalWinnings = 0;

        // Create a new dealer for the Baccarat game and set up game logic
        theDealer = new BaccaratDealer();
        gameLogic = new BaccaratGameLogic();
        
        // Main layout container for the game UI
        VBox mainLayout = new VBox(15);
        mainLayout.setAlignment(Pos.CENTER);

        // Add menu bar to the main layout
        mainLayout.getChildren().add(createMenuBar());

        // Secondary layout container for the game elements
        VBox gameLayout = new VBox(25);
        gameLayout.setAlignment(Pos.CENTER);

        // Labels to display game info and card details for player and banker
        infoLabel = new Label("Place your bet!");
        playerCardsLabel = new Label("Player cards: ");
        bankerCardsLabel = new Label("Banker cards: ");

        // Container for betting controls
        bettingBox = new VBox(10);
        bettingBox.setAlignment(Pos.CENTER);

        // Text field for the player to enter their bet amount
        TextField betField = new TextField();
        betField.setPromptText("Enter bet amount");
        
        // Button to place a bet on the player
        Button playerBetButton = new Button("Bet on Player");
        playerBetButton.setOnAction(e -> {
            try {
                double betAmount = Double.parseDouble(betField.getText());
                placeBet("Player", betAmount);
            } catch (NumberFormatException ex) {
                // Handle invalid bet amount input
                infoLabel.setText("Invalid bet amount!");
            }
        });

        // Button to place a bet on the banker
        Button bankerBetButton = new Button("Bet on Banker");
        bankerBetButton.setOnAction(e -> {
            try {
                double betAmount = Double.parseDouble(betField.getText());
                placeBet("Banker", betAmount);
            } catch (NumberFormatException ex) {
                // Handle invalid bet amount input
                infoLabel.setText("Invalid bet amount!");
            }
        });

        // Button to place a bet on a draw
        Button drawBetButton = new Button("Bet on Draw");
        drawBetButton.setOnAction(e -> {
            try {
                double betAmount = Double.parseDouble(betField.getText());
                placeBet("Draw", betAmount);
            } catch (NumberFormatException ex) {
                // Handle invalid bet amount input
                infoLabel.setText("Invalid bet amount!");
            }
        });

        // Add betting controls to the betting box
        bettingBox.getChildren().addAll(betField, playerBetButton, bankerBetButton, drawBetButton);

        // Add game info, card details, and betting box to the game layout
        gameLayout.getChildren().addAll(infoLabel, playerCardsLabel, bankerCardsLabel, bettingBox);

        // Button to reset and play another round
        playAgainButton = new Button("Play Again");
        playAgainButton.setOnAction(e -> resetRound());
        playAgainButton.setVisible(false); // Hide until the end of a round
        gameLayout.getChildren().add(playAgainButton);

        // Display total winnings at the bottom of the screen
        totalWinningsLabel = new Label("Total Winnings: $0");
        HBox bottomBox = new HBox();
        bottomBox.getChildren().add(totalWinningsLabel);
        bottomBox.setAlignment(Pos.BOTTOM_LEFT);
        mainLayout.getChildren().addAll(gameLayout, bottomBox);
        
        // Set up the game scene and display it on the primary stage
        Scene gameScene = new Scene(mainLayout, 400, 600);
        primaryStage.setScene(gameScene);
    }


    //Start game
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Baccarat Game");
        startGame();
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
