import java.util.ArrayList;

class BaccaratGameLogic {

    // Determines which hand won: Player, Banker, or if it's a Draw
    public String whoWon(ArrayList<Card> hand1, ArrayList<Card> hand2) {
        int playerTotal = handTotal(hand1);
        int bankerTotal = handTotal(hand2);

        if(playerTotal > bankerTotal) return "Player";
        if(bankerTotal > playerTotal) return "Banker";
        return "Draw"; // If neither player nor banker has a higher total, it's a draw
    }

    // Calculates the total value of a hand in Baccarat
    public int handTotal(ArrayList<Card> hand) {
        int total = 0;
        for (Card card : hand) {
            // Card values greater than 10 count as 0 in Baccarat
            total += card.value > 10 ? 0 : card.value; 
        }
        // In Baccarat, only the last digit of the total counts
        return total % 10;
    }

    // Determines if the player should draw a card based on their total
    public boolean evaluatePlayerDraw(ArrayList<Card> hand) {
        int total = handTotal(hand);
        // Player draws a card if their total is 5 or less
        return total <= 5;
    }

    // Determines if the banker should draw a card
    public boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) {
        int total = handTotal(hand);
        // If banker's total is 2 or less, always draw
        if (total <= 2) return true;
        // If banker's total is 7 or more, never draw
        if (total >= 7) return false;
        
        // Here we account for the rules of whether the banker should draw a card based on the player's third card.
        if (playerCard == null) {
            // If player does not draw a card, the banker draws if their total is 5 or less
            return total <= 5;
        } else {
            // If player draws a card, use its value to determine if the banker should draw
            int playerCardValue = playerCard.value > 10 ? 0 : playerCard.value;
            switch (total) {
                case 3:
                    // Banker draws unless player's third card is an 8
                    return playerCardValue != 8;
                case 4:
                    // Banker draws if player's third card is between 2 and 7 inclusive
                    return playerCardValue >= 2 && playerCardValue <= 7;
                case 5:
                    // Banker draws if player's third card is between 4 and 7 inclusive
                    return playerCardValue >= 4 && playerCardValue <= 7;
                case 6:
                    // Banker draws if player's third card is a 6 or 7
                    return playerCardValue == 6 || playerCardValue == 7;
            }
        }
        return false;
    }
}
