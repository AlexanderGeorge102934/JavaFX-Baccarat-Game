import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest3 {
	
	BaccaratGame game;

    // Setup method to initialize the BaccaratGame instance before each test
    @BeforeEach
    public void setup() {
        game = new BaccaratGame();
        game.theDealer = new BaccaratDealer();
        game.gameLogic = new BaccaratGameLogic();
    }

    @Test
    public void testPlayerWinsBetOnPlayer() {
        // Setting up the bet type and bet amount
        game.betType = "Player";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where player's hand total is 9 and banker's hand total is 8
        game.playerHand.add(new Card("Hearts", 7));
        game.playerHand.add(new Card("Diamonds", 2));

        game.bankerHand.add(new Card("Spades", 5));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(10.0, winnings);
    }
    
    @Test
    public void testPlayerWinsBetOnPlayerLost() {
        // Setting up the bet type and bet amount
        game.betType = "Player";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where player's hand total is 9 and banker's hand total is 8
        game.playerHand.add(new Card("Hearts", 2));
        game.playerHand.add(new Card("Diamonds", 4));

        game.bankerHand.add(new Card("Spades", 5));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(-10.0, winnings);
    }
    
    @Test
    public void testBankerWinsBetOnBanker() {
        // Setting up the bet type and bet amount
        game.betType = "Banker";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where player's hand total is 7 and banker's hand total is 9
        game.playerHand.add(new Card("Hearts", 5));
        game.playerHand.add(new Card("Diamonds", 2));

        game.bankerHand.add(new Card("Spades", 6));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        // Banker bet has a 5% commission so expected winnings is 10.0 - 0.5 = 9.5
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(9.5, winnings);
    }

    @Test
    public void testDrawGameBetOnDraw() {
        // Setting up the bet type and bet amount
        game.betType = "Draw";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where both player's and banker's hand totals are 8
        game.playerHand.add(new Card("Hearts", 6));
        game.playerHand.add(new Card("Diamonds", 2));

        game.bankerHand.add(new Card("Spades", 5));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        // Draw bet has an 8:1 payout so expected winnings is 10.0 * 8 = 80.0
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(80.0, winnings);
    }
	
	
}