import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Ctest3 {

    // Test the initialization and behavior of the Card class

    // Test the initialization of numeric cards
    @Test
    public void testNumericCardInitialization() {
        Card card = new Card("Hearts", 7);

        assertEquals("Hearts", card.suite);
        assertEquals(7, card.value);
        assertNull(card.FaceCard);
    }

    // Test the initialization of face cards
    @Test
    public void testFaceCardInitialization() {
        Card card = new Card("Diamonds", "King", 10);

        assertEquals("Diamonds", card.suite);
        assertEquals("King", card.FaceCard);
        assertEquals(10, card.value);
    }

    // Test the behavior of setting and getting suite
    @Test
    public void testSuiteSetAndGet() {
        Card card = new Card("Clubs", 5);
        card.suite = "Spades";

        assertEquals("Spades", card.suite);
    }

    // Test the behavior of setting and getting value for numeric cards
    @Test
    public void testValueSetAndGetNumericCard() {
        Card card = new Card("Clubs", 5);
        card.value = 8;

        assertEquals(8, card.value);
    }

    // Test the behavior of setting and getting value for face cards
    @Test
    public void testValueSetAndGetFaceCard() {
        Card card = new Card("Diamonds", "Queen", 10);
        card.value = 0;

        assertEquals(0, card.value);
    }

    // Test the behavior of setting and getting the face card value
    @Test
    public void testFaceCardSetAndGet() {
        Card card = new Card("Diamonds", "Queen", 10);
        card.FaceCard = "Ace";

        assertEquals("Ace", card.FaceCard);
    }
}
