import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {
	
	BaccaratDealer dealer;
	
    BaccaratGameLogic gameLogic;// Instance variable for the Baccarat game logic which will be used for testing
    
    BaccaratGame game;
	
	
	@BeforeEach
    public void setup() {
        dealer = new BaccaratDealer();
        gameLogic = new BaccaratGameLogic();
        game = new BaccaratGame();
        game.theDealer = new BaccaratDealer();
        game.gameLogic = new BaccaratGameLogic();
    }

	// Test if the deck is generated with the correct size of 52 cards
    @Test
    public void testGenerateDeckSize() {
        assertEquals(52, dealer.deckSize(), "Deck should contain 52 cards after generation.");
    }

    // Test if the deck has been shuffled by comparing the first card before and after shuffling
    @Test
    public void testShuffleDeck() {
        Card firstCardBeforeShuffle = dealer.deck.get(0);
        dealer.shuffleDeck();
        Card firstCardAfterShuffle = dealer.deck.get(0);
        assertNotEquals(firstCardBeforeShuffle, firstCardAfterShuffle, "Deck should be shuffled.");
    }
    
    // Test if the deck has been shuffled by comparing the first card before and after shuffling
    @Test
    public void testShuffleDeck2() {
        Card firstCardBeforeShuffle = dealer.deck.get(0);
        dealer.shuffleDeck();
        Card firstCardAfterShuffle = dealer.deck.get(0);
        assertNotEquals(firstCardBeforeShuffle, firstCardAfterShuffle, "Deck should be shuffled.");
    }

    // Test if the dealHand method returns an ArrayList of 2 cards and also reduces the deck size by 2
    @Test
    public void testDealHand() {
        ArrayList<Card> hand = dealer.dealHand();
        assertEquals(2, hand.size(), "Hand should contain 2 cards.");
        assertEquals(50, dealer.deckSize(), "Deck should have 50 cards remaining after dealing a hand.");
    }

    // Test if drawOne deals a single card and reduces the deck size by 1
    @Test
    public void testDrawOne() {
        Card drawnCard = dealer.drawOne();
        assertNotNull(drawnCard, "Drawn card should not be null.");
        assertEquals(51, dealer.deckSize(), "Deck should have 51 cards remaining after drawing one card.");
    }

    // Test if drawOne deals a single card and reduces the deck size by 1
    @Test
    public void testDrawOne2() {
        Card drawnCard = dealer.drawOne();
        dealer.drawOne();
        assertNotNull(drawnCard, "Drawn card should not be null.");
        assertEquals(50, dealer.deckSize(), "Deck should have 50 cards remaining after drawing one card.");
    }
    
    // Test if the deckSize method correctly returns the number of cards in the deck
    @Test
    public void testDeckSize() {
        assertEquals(52, dealer.deckSize(), "Initial deck size should be 52.");
        dealer.drawOne();
        assertEquals(51, dealer.deckSize(), "After drawing one card, deck size should be 51.");
    }
    
    // Test if the deckSize method correctly returns the number of cards in the deck
    @Test
    public void testDeckSize2() {
        assertEquals(52, dealer.deckSize(), "Initial deck size should be 52.");
        dealer.drawOne();
        dealer.drawOne();
        dealer.drawOne();
        assertEquals(49, dealer.deckSize(), "After drawing one card, deck size should be 49.");
    }

    // Test if a new deck is generated when the deck is empty
    @Test
    public void testDrawWithEmptyDeck() {
        for (int i = 0; i < 52; i++) {
            dealer.drawOne();
        }
        assertEquals(0, dealer.deckSize(), "Deck should be empty.");

        Card drawnCard = dealer.drawOne();
        assertNotNull(drawnCard, "Should be able to draw a card even after the deck is empty (a new deck should be generated).");
        assertEquals(51, dealer.deckSize(), "After drawing from an empty deck, a new deck should be generated and its size should be 51.");
    }
    
    // Testing the scenario where the player has a winning hand
    @Test
    public void testWhoWonPlayer() {
        // Define player and banker hands
        ArrayList<Card> playerHand = new ArrayList<>();
        playerHand.add(new Card("Hearts", 2));
        playerHand.add(new Card("Diamonds", 5));

        ArrayList<Card> bankerHand = new ArrayList<>();
        bankerHand.add(new Card("Hearts", 2));
        bankerHand.add(new Card("Diamonds", 4));

        // Assert that the game logic correctly identifies the player as the winner
        assertEquals("Player", gameLogic.whoWon(playerHand, bankerHand));
    }
    
    // Testing the scenario where the banker has a winning hand
    @Test
    public void testWhoWonBanker() {
        // Define player and banker hands
        ArrayList<Card> playerHand = new ArrayList<>();
        playerHand.add(new Card("Hearts", 2));
        playerHand.add(new Card("Diamonds", 2));

        ArrayList<Card> bankerHand = new ArrayList<>();
        bankerHand.add(new Card("Hearts", 2));
        bankerHand.add(new Card("Diamonds", 4));

        // Assert that the game logic correctly identifies the player as the winner
        assertEquals("Banker", gameLogic.whoWon(playerHand, bankerHand));
    }

    // Testing hand total calculation when the hand contains face cards and numbers
    @Test
    public void testHandTotalWithFaceCards() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", "King", 0));
        hand.add(new Card("Diamonds", "Queen", 0));
        hand.add(new Card("Clubs", 5));

        // Assert that the game logic correctly calculates the hand's total as 5
        assertEquals(5, gameLogic.handTotal(hand));
    }

    // Testing if the player should correctly draw a third card given a specific hand total
    @Test
    public void testEvaluatePlayerDrawTrue() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 2));

        // Assert that the game logic suggests player should draw a card when their hand total is 4
        assertTrue(gameLogic.evaluatePlayerDraw(hand));
    }

    // Testing banker's decision to draw based on player's third card
    @Test
    public void testEvaluateBankerDrawWithPlayerCard() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 3));
        hand.add(new Card("Diamonds", 3));

        // Player's third card
        Card playerCard = new Card("Clubs", 4);

        // Assert that the banker should not draw a third card in this situation
        assertFalse(gameLogic.evaluateBankerDraw(hand, playerCard));
    }

    // Testing banker's decision to draw when they have a total of 2 and no player's third card
    @Test
    public void testEvaluateBankerDrawWithoutPlayerCardTotal2() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 1));
        hand.add(new Card("Diamonds", 1));

        // Assert that the banker should draw a card when their hand total is 2 and no player card
        assertTrue(gameLogic.evaluateBankerDraw(hand, null));
    }

    // Testing banker's decision to draw when they have a total of 7 and no player's third card
    @Test
    public void testEvaluateBankerDrawWithoutPlayerCardTotal7() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 3));
        hand.add(new Card("Diamonds", 4));

        // Assert that the banker should not draw a card when their hand total is 7
        assertFalse(gameLogic.evaluateBankerDraw(hand, null));
    }

    // Testing banker's decision based on its own total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal3() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 1));

        Card playerCard = new Card("Clubs", 8); 

        // Banker should not draw if its total is 3 and player's third card is 8
        assertFalse(gameLogic.evaluateBankerDraw(hand, playerCard));
    }

    // Testing another scenario for the banker's decision based on its total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal4() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 2));

        Card playerCard = new Card("Clubs", 1); 

        assertFalse(gameLogic.evaluateBankerDraw(hand, playerCard));
    }

    // Testing another scenario for the banker's decision based on its total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal4part2() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 2));

        Card playerCard = new Card("Clubs", 8); 

        assertFalse(gameLogic.evaluateBankerDraw(hand, playerCard));
    }
    
    // Testing another scenario for the banker's decision based on its total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal5part1() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 3));

        Card playerCard = new Card("Clubs", 4); 

        assertTrue(gameLogic.evaluateBankerDraw(hand, playerCard));
    }

    // Testing another scenario for the banker's decision based on its total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal5part2() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 3));

        Card playerCard = new Card("Clubs", 7); 

        assertTrue(gameLogic.evaluateBankerDraw(hand, playerCard));
    }
    
    
    // Testing another scenario for the banker's decision based on its total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal6part1() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 3));
        hand.add(new Card("Diamonds", 3));

        Card playerCard = new Card("Clubs", 6); 

        assertTrue(gameLogic.evaluateBankerDraw(hand, playerCard));
    }
    
    // Testing another scenario for the banker's decision based on its total and the player's third card value
    @Test
    public void testEvaluateBankerDrawWithPlayerCardTotal6part2() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 3));
        hand.add(new Card("Diamonds", 3));

        Card playerCard = new Card("Clubs", 2); 

        assertFalse(gameLogic.evaluateBankerDraw(hand, playerCard));
    }
    
    @Test
    public void testPlayerWinsBetOnPlayer() {
        // Setting up the bet type and bet amount
        game.betType = "Player";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where player's hand total is 9 and banker's hand total is 8
        game.playerHand.add(new Card("Hearts", 7));
        game.playerHand.add(new Card("Diamonds", 2));

        game.bankerHand.add(new Card("Spades", 5));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(10.0, winnings);
    }
    
    @Test
    public void testPlayerWinsBetOnPlayerLost() {
        // Setting up the bet type and bet amount
        game.betType = "Player";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where player's hand total is 9 and banker's hand total is 8
        game.playerHand.add(new Card("Hearts", 2));
        game.playerHand.add(new Card("Diamonds", 4));

        game.bankerHand.add(new Card("Spades", 5));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(-10.0, winnings);
    }
    
    @Test
    public void testBankerWinsBetOnBanker() {
        // Setting up the bet type and bet amount
        game.betType = "Banker";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where player's hand total is 7 and banker's hand total is 9
        game.playerHand.add(new Card("Hearts", 5));
        game.playerHand.add(new Card("Diamonds", 2));

        game.bankerHand.add(new Card("Spades", 6));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        // Banker bet has a 5% commission so expected winnings is 10.0 - 0.5 = 9.5
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(9.5, winnings);
    }

    @Test
    public void testDrawGameBetOnDraw() {
        // Setting up the bet type and bet amount
        game.betType = "Draw";
        game.currentBet = 10.0;

        // Initializing hands for player and banker
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        // Simulating the scenario where both player's and banker's hand totals are 8
        game.playerHand.add(new Card("Hearts", 6));
        game.playerHand.add(new Card("Diamonds", 2));

        game.bankerHand.add(new Card("Spades", 5));
        game.bankerHand.add(new Card("Clubs", 3));

        // Evaluating winnings based on the set scenario
        // Draw bet has an 8:1 payout so expected winnings is 10.0 * 8 = 80.0
        double winnings = game.evaluateWinnings();

        // Asserting that the winnings are correctly calculated
        assertEquals(80.0, winnings);
    }
    
    

}
